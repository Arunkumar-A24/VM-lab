# config.py

ZONES = ["Red", "Yellow", "Green"]

BOOKING_STATUS = {
    "SCHEDULED": "Scheduled",
    "ACTIVE": "Active",
    "EXPIRED": "Expired"
}
